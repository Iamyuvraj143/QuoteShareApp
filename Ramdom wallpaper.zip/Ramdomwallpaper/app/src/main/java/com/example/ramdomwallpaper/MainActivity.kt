package com.example.ramdomwallpaper

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.RestrictTo
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.ramdomwallpaper.databinding.ActivityMainBinding
import org.json.JSONObject
import java.io.IOException
import java.nio.charset.Charset
import java.util.*
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    var qu: String? = null
    var aa: String? = null
    var TotalQuestion= 0
    var TotalScore = 0
        /*   var optionOne: String? = null
    var optionTwo: String? = null
    var optionThree: String? = null
    var optionFour: String? = null  */


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_main)

        binding= DataBindingUtil.setContentView(this, R.layout.activity_main)
        LoadApi()

    }

        fun LoadApi(){

           val url = "https://api.forismatic.com/api/1.0/?method=getQuote&lang=en&format=json"

// Request a string response from the provided URL.
           val jsonObjectRequest = JsonObjectRequest(Request.Method.GET, url, null,
               Response.Listener { response ->

                   qu = response.getString("quoteText")
                 var  optionOne = response.getString("quoteAuthor")
                 var  optionTwo = response.getString("senderName")
                 var  optionThree= response.getString("senderLink")
                 var  optionFour = response.getString("quoteLink")
              //     aa=response.getString("ans")




                   binding.pic.setImageResource(R.drawable.qmark)
                   binding.questionText.setText(qu)
                   binding.op1.setText(optionOne)
                   binding.op2.setText(optionTwo)
                   binding.op3.setText(optionThree)
                   binding.op4.setText(optionFour)
                   binding.point.setText("Score is $TotalScore out of $TotalQuestion Question")
                   TotalQuestion=TotalQuestion+1



               },
               Response.ErrorListener {
                   Toast.makeText(this, "something went wrong", Toast.LENGTH_LONG).show()
               })

// Add the request to the RequestQueue.
            MySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest)

        }

    fun check4(view: View) {

        if(aa=="4") {
            binding.pic.setImageResource(R.drawable.right)
            TotalScore = TotalScore + 1
        }else{
            binding.pic.setImageResource(R.drawable.wrong)
            binding.questionText.setText("Wrong Answer \n Option $aa")
            binding.op4.setText("Correct Answer is $aa")
        }

         Thread.sleep(1000)
        LoadApi()

    }

    fun check3(view: View) {
        if(aa=="3") {
            binding.pic.setImageResource(R.drawable.right)
            TotalScore = TotalScore + 1
        }else{
            binding.pic.setImageResource(R.drawable.wrong)
            binding.questionText.setText("Wrong Answer \n Option $aa")
            binding.op3.setText("Correct Answer is $aa")


        }
        Thread.sleep(1000)

        LoadApi()

    }
    fun check1(view: View) {
        if(aa=="1") {
            binding.pic.setImageResource(R.drawable.right)
            TotalScore = TotalScore + 1
        }else{
            binding.pic.setImageResource(R.drawable.wrong)
            binding.questionText.setText("Wrong Answer \n Option $aa")
            binding.op1.setText("Correct Answer is $aa")
        }
        Thread.sleep(1000)
        LoadApi()

    }
    fun check2(view: View) {
        if(aa=="2") {
            binding.pic.setImageResource(R.drawable.right)
            TotalScore = TotalScore + 1
        }else{
            binding.pic.setImageResource(R.drawable.wrong)
            binding.questionText.setText("Wrong Answer \n Option $aa")
            binding.op2.setText("Correct Answer is $aa")
        }
        Thread.sleep(1000)
        LoadApi()

    }

    fun btfun(view: View) {
        LoadApi()
    }

}
